const express = require ('express');
const app = express();
const port = 3000;
const path = require('path');
const methodOverride = require('method-override');
const { v4: uuidv4 } = require('uuid');
app.set("view engine","ejs");
app.set(path.join(__dirname,'views'));
app.listen(port,()=>{
    console.log('listening');
});
app.use(express.static(path.join(__dirname,'public')));
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method'));
let posts = [
    {
        'id':uuidv4(),
        'username': 'Sehez Babber',
        'content': 'what a great weather today'
    },
    {
        'id':uuidv4(),
        'username': 'John Doe',
        'content': 'Enjoying my weekend at the beach!'
    },
    {
        'id':uuidv4(),
        'username': 'Alice Smith',
        'content': 'Just finished reading an amazing book.'
    },
    {
        'id':uuidv4(),
        'username': 'Emily Brown',
        'content': 'Trying out a new recipe for dinner.'
    },
    {
        'id':uuidv4(),
        'username': 'David Lee',
        'content': 'Excited for the upcoming concert!'
    },
    {
        'id':uuidv4(),
        'username': 'Sophia Garcia',
        'content': 'Exploring a new hiking trail today.'
    },
    {
        'id':uuidv4(),
        'username': 'Michael Wang',
        'content': 'Celebrating my dog\'s birthday!'
    }
];

app.get('/home',(req,res)=>{
    res.render('home.ejs',{posts});
});
app.get('/home/:id',(req,res)=>{
    let {id} = req.params;
    let q;
    for(let post of posts){
        if(post.id === id){
            q = post;
            break;
        }
    }
    res.render('indetail.ejs',{q});
});
app.get('/add',(req,res)=>{
    res.render('add.ejs');
});
app.post('/add',(req,res)=>{
    let {id} = uuidv4();
    console.log(req.body);
    let {username} = req.body;
    let {content} = req.body;
    let p = {
        'id':id,
        'username':username,
        'content':content,
    }
    posts.push(p);
    res.redirect('/home');
});
app.post('/home',(req,res)=>{
    let {id} = req.body;
    let pos = posts.filter(item=>item.id!==id);
    posts = pos;
    res.redirect('/home');
});
app.get('/home/:id/edit',(req,res)=>{
    let {id} = req.params;
    console.log(id);
    let post = posts.find(p=> id === p.id); 
    console.log(post);
    res.render('edit.ejs',{post});
});
app.patch('/home/:id',(req,res)=>{
    let {username} = req.body;
    let {content} = req.body;
    let {id} = req.params;
    let post = posts.find(p=> id === p.id);
    post.username = username;
    post.content = content;
    res.render('home.ejs',{posts});
});